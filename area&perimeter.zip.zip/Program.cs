﻿using System;
public interface IShape
{
    double area();
    double perimeter();
}
public class Rectangle : IShape
{
    public double Length { get; set; }
    public double Width { get; set; }

    public double area()
    {
        return Length * Width;
    }

    public double perimeter()
    {
        return 2 * (Length + Width);
    }
}
public class Square : IShape
{
    public double SideLength { get; set; }

    public double area()
    {
        return SideLength * SideLength;
    }

    public double perimeter()
    {
        return 4 * SideLength;
    }
}
class program {
static void Main(string[] args)
{
    Rectangle rectangle = new Rectangle { Length = 2, Width = 12 };
    Console.WriteLine("Rectangle area: " + rectangle.area());
    Console.WriteLine("Rectangle perimeter: " + rectangle.perimeter());

    Square square = new Square { SideLength = 4 };
    Console.WriteLine("Square area: " + square.area());
    Console.WriteLine("Square perimeter: " + square.perimeter());

    Console.ReadKey();
}
}
